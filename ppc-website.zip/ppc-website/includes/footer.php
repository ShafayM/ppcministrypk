<footer class="site-footer">
  <div class="container">
    <div class="footer-top">
      <div class="footer-brand">
        <span class="brand-name" style="color:var(--parchment)"><?= h(SITE_SHORT) ?><small style="color:var(--gold-soft)"><?= h(SITE_NAME) ?></small></span>
        <p>Ministering in <?= h(SITE_LOCATION) ?> since <?= h(SITE_SINCE) ?>. A home for worship, discipleship, and reaching the nations.</p>
      </div>
      <div>
        <h4>Visit</h4>
        <ul>
          <li><a href="pastors.php">Pastors</a></li>
          <li><a href="local-church.php">Local Church</a></li>
          <li><a href="sunday-school.php">Sunday School</a></li>
        </ul>
      </div>
      <div>
        <h4>Get Involved</h4>
        <ul>
          <li><a href="ministries.php">Ministry Projects</a></li>
          <li><a href="conventions.php">Conventions</a></li>
          <li><a href="welfare.php">LikeChrist Welfare</a></li>
        </ul>
      </div>
      <div>
        <h4>Contact</h4>
        <ul>
          <li><a href="mailto:<?= h(SITE_EMAIL) ?>"><?= h(SITE_EMAIL) ?></a></li>
          <li><a href="tel:<?= h(str_replace(' ', '', SITE_PHONE)) ?>"><?= h(SITE_PHONE) ?></a></li>
          <li><?= h(SITE_LOCATION) ?></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <span>© <?= date('Y') ?> <?= h(SITE_NAME) ?>. All rights reserved.</span>
      <a href="admin/login.php">Church Admin</a>
    </div>
  </div>
</footer>

<script src="assets/js/main.js"></script>
</body>
</html>
