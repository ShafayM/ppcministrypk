<?php
/**
 * PPC Website — core configuration & helper functions.
 * Edit ADMIN_PASSWORD below (then delete this comment) to set your admin login.
 */

session_start();

// ---- Site-wide settings ----------------------------------------------------
define('SITE_NAME', 'Philadelphia Pentecostal Church');
define('SITE_SHORT', 'PPC');
define('SITE_LOCATION', 'Nawabshah, Sindh, Pakistan');
define('SITE_SINCE', '1974');
define('SITE_EMAIL', 'philadelphiapentecostalchurchp@gmail.com');
define('SITE_PHONE', '+92 343 210 9654');
define('SITE_PASTOR', 'Pastor Sham Samuel');

// Change this password, then tell only trusted church admins.
// To set a new password: run  php -r "echo password_hash('yourpassword', PASSWORD_DEFAULT);"
// and paste the result below.
define('ADMIN_PASSWORD_HASH', '$2y$10$73EDiFIlZtBvX3KCMuqwdOrM6Y8JJ90ok7qfZimirL4HHTZ877RAe');
// Default password for first login is:  PPCnawabshah1974
// (Change it right away — see README.md for how to generate a new hash.)

define('BASE_PATH', dirname(__DIR__));
define('DATA_PATH', BASE_PATH . '/data');
define('UPLOADS_PATH', BASE_PATH . '/uploads');
define('UPLOADS_URL', 'uploads');

// ---- Small helpers ----------------------------------------------------------
function h($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

function is_admin() {
    return !empty($_SESSION['ppc_admin']);
}

function require_admin() {
    if (!is_admin()) {
        header('Location: login.php');
        exit;
    }
}

/** Read a JSON data file from /data, return $default if missing/broken. */
function get_json($name, $default = []) {
    $file = DATA_PATH . '/' . $name . '.json';
    if (!file_exists($file)) return $default;
    $contents = file_get_contents($file);
    $decoded = json_decode($contents, true);
    return is_array($decoded) ? $decoded : $default;
}

/** Write an array back to a JSON data file in /data. */
function save_json($name, $data) {
    $file = DATA_PATH . '/' . $name . '.json';
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
}

/** List uploaded image filenames for a section (e.g. 'pastors', 'welfare'). */
function get_images($section) {
    $dir = UPLOADS_PATH . '/' . $section;
    if (!is_dir($dir)) return [];
    $files = array_values(array_diff(scandir($dir), ['.', '..', '.gitkeep']));
    natsort($files);
    return array_values($files);
}

/** Full site-relative URL to an uploaded image. */
function image_url($section, $filename) {
    return UPLOADS_URL . '/' . $section . '/' . rawurlencode($filename);
}

/** Handle a photo upload from $_FILES[$field] into a section folder. Returns [ok, message]. */
function handle_upload($field, $section) {
    if (empty($_FILES[$field]) || $_FILES[$field]['error'] === UPLOAD_ERR_NO_FILE) {
        return [false, 'No file selected.'];
    }
    $file = $_FILES[$field];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return [false, 'Upload failed (error code ' . $file['error'] . ').'];
    }
    $allowed = ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!array_key_exists($ext, $allowed)) {
        return [false, 'Please upload a JPG, PNG, or WEBP image.'];
    }
    if ($file['size'] > 8 * 1024 * 1024) {
        return [false, 'That image is larger than 8MB — please use a smaller file.'];
    }
    $dir = UPLOADS_PATH . '/' . $section;
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    $safeName = preg_replace('/[^a-zA-Z0-9_-]/', '-', pathinfo($file['name'], PATHINFO_FILENAME));
    $filename = $safeName . '-' . substr(md5(uniqid()), 0, 6) . '.' . $ext;
    if (!move_uploaded_file($file['tmp_name'], $dir . '/' . $filename)) {
        return [false, 'Could not save the uploaded file.'];
    }
    return [true, $filename];
}

function delete_image($section, $filename) {
    $filename = basename($filename);
    $path = UPLOADS_PATH . '/' . $section . '/' . $filename;
    if (file_exists($path)) {
        unlink($path);
        return true;
    }
    return false;
}
