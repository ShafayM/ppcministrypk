<?php
/**
 * Shared header. Each page sets $page_slug (for active nav) and
 * $page_title / $page_description before including this file.
 */
require_once __DIR__ . '/config.php';
$page_slug = $page_slug ?? '';
$page_title = $page_title ?? SITE_NAME;
$page_description = $page_description ?? 'Philadelphia Pentecostal Church — ministering in Nawabshah, Sindh since 1974.';

$nav_items = [
    'home'          => ['label' => 'Home',            'href' => 'index.php'],
    'pastors'       => ['label' => 'Pastors',          'href' => 'pastors.php'],
    'ministries'    => ['label' => 'Ministries',       'href' => 'ministries.php'],
    'local-church'  => ['label' => 'Local Church',     'href' => 'local-church.php'],
    'sunday-school' => ['label' => 'Sunday School',    'href' => 'sunday-school.php'],
    'conventions'   => ['label' => 'Conventions',      'href' => 'conventions.php'],
    'welfare'       => ['label' => 'LikeChrist Welfare','href' => 'welfare.php'],
];
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= h($page_title) ?> — <?= h(SITE_NAME) ?></title>
<meta name="description" content="<?= h($page_description) ?>">
<link rel="icon" href="data:,">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<header class="site-header">
  <div class="nav-inner">
    <a href="index.php" class="brand">
      <span class="brand-mark">
        <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill="#F7F1E3" d="M12 2c.6 2.6-.9 4-2 5.4C8.6 9 8 10.4 8 12a4 4 0 0 0 8 0c0-1-.3-1.8-.8-2.6.9.7 1.8 2 1.8 3.9a5 5 0 0 1-10 0c0-3.4 2.4-5 3.8-6.7C11.6 5.4 12.2 3.8 12 2Z"/></svg>
      </span>
      <span class="brand-name"><?= h(SITE_SHORT) ?><small>Philadelphia Pentecostal Church</small></span>
    </a>
    <nav class="nav-links" aria-label="Primary">
      <?php foreach ($nav_items as $slug => $item): ?>
        <a href="<?= h($item['href']) ?>" class="<?= $page_slug === $slug ? 'active' : '' ?>"><?= h($item['label']) ?></a>
      <?php endforeach; ?>
      <a href="welfare.php#give" class="btn btn-gold nav-cta">Give</a>
    </nav>
    <button class="nav-toggle" aria-label="Toggle menu">
      <span></span><span></span><span></span>
    </button>
  </div>
</header>
