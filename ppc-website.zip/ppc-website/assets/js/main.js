document.addEventListener('DOMContentLoaded', function () {
  // Sticky header solidifies after scrolling past the hero
  var header = document.querySelector('.site-header');
  if (header) {
    var solidify = function () {
      if (window.scrollY > 60) header.classList.add('solid');
      else header.classList.remove('solid');
    };
    solidify();
    window.addEventListener('scroll', solidify, { passive: true });
  }

  // Mobile nav toggle
  var toggle = document.querySelector('.nav-toggle');
  var links = document.querySelector('.nav-links');
  if (toggle && links) {
    toggle.addEventListener('click', function () {
      links.classList.toggle('open');
      document.body.classList.toggle('nav-open');
    });
    links.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () {
        links.classList.remove('open');
        document.body.classList.remove('nav-open');
      });
    });
  }

  // Lightweight lightbox for gallery images
  var galleryImgs = document.querySelectorAll('.gallery img');
  if (galleryImgs.length) {
    var overlay = document.createElement('div');
    overlay.setAttribute('id', 'lightbox-overlay');
    overlay.style.cssText = 'display:none;position:fixed;inset:0;background:rgba(16,14,38,.92);z-index:999;align-items:center;justify-content:center;padding:5vw;cursor:zoom-out;';
    var img = document.createElement('img');
    img.style.cssText = 'max-width:100%;max-height:90vh;border-radius:6px;box-shadow:0 20px 60px rgba(0,0,0,.5);';
    overlay.appendChild(img);
    document.body.appendChild(overlay);

    galleryImgs.forEach(function (el) {
      el.addEventListener('click', function () {
        img.src = el.src;
        overlay.style.display = 'flex';
      });
    });
    overlay.addEventListener('click', function () { overlay.style.display = 'none'; });
  }
});
