<?php
require_once __DIR__ . '/../includes/config.php';
require_admin();

$sections = [
    'home'          => 'Homepage & Hero Photo',
    'pastors'       => 'Pastors',
    'ministries'    => 'Ministries',
    'local-church'  => 'Local Church',
    'sunday-school' => 'Sunday School',
    'conventions'   => 'Conventions',
    'welfare'       => 'LikeChrist Welfare',
];

// Text fields per section (key => [label, type])
$field_defs = [
    'home' => [
        ['key' => 'hero_title', 'label' => 'Hero Title', 'type' => 'text'],
        ['key' => 'hero_lede', 'label' => 'Hero Subtitle', 'type' => 'textarea'],
        ['key' => 'spotlight_quote', 'label' => "Pastor's Spotlight Quote", 'type' => 'textarea'],
        ['key' => 'spotlight_name', 'label' => 'Quote Attribution', 'type' => 'text'],
        ['key' => 'find_place_note', 'label' => '"Find Your Place" Heading', 'type' => 'textarea'],
    ],
    'pastors' => [
        ['key' => 'intro', 'label' => 'Introduction', 'type' => 'textarea'],
        ['key' => 'senior_pastor_name', 'label' => 'Senior Pastor Name', 'type' => 'text'],
        ['key' => 'senior_pastor_role', 'label' => 'Senior Pastor Role', 'type' => 'text'],
        ['key' => 'senior_pastor_bio', 'label' => 'Senior Pastor Bio', 'type' => 'textarea'],
        ['key' => 'leadership_note', 'label' => 'Leadership Team Note', 'type' => 'textarea'],
    ],
    'ministries' => [
        ['key' => 'intro', 'label' => 'Introduction', 'type' => 'textarea'],
        ['key' => 'reach_title', 'label' => 'Mission Arm Title', 'type' => 'text'],
        ['key' => 'reach_body', 'label' => 'Mission Arm Description', 'type' => 'textarea'],
        ['key' => 'projects_note', 'label' => 'Projects Gallery Note', 'type' => 'textarea'],
    ],
    'local-church' => [
        ['key' => 'intro', 'label' => 'Introduction', 'type' => 'textarea'],
        ['key' => 'life_note', 'label' => '"Beyond Sunday" Note', 'type' => 'textarea'],
    ],
    'sunday-school' => [
        ['key' => 'intro', 'label' => 'Introduction', 'type' => 'textarea'],
        ['key' => 'schedule_note', 'label' => 'Schedule Note', 'type' => 'text'],
        ['key' => 'teachers_note', 'label' => 'Teachers Note', 'type' => 'textarea'],
    ],
    'conventions' => [
        ['key' => 'intro', 'label' => 'Introduction', 'type' => 'textarea'],
        ['key' => 'conventions_note', 'label' => 'Conventions Note', 'type' => 'textarea'],
        ['key' => 'problems_title', 'label' => 'Needs Section Title', 'type' => 'text'],
        ['key' => 'problems_note', 'label' => 'Local Church Needs Note', 'type' => 'textarea'],
        ['key' => 'prayer_note', 'label' => 'Prayer Contact Note', 'type' => 'textarea'],
    ],
    'welfare' => [
        ['key' => 'intro', 'label' => 'Introduction', 'type' => 'textarea'],
        ['key' => 'mission', 'label' => 'Mission Statement', 'type' => 'textarea'],
        ['key' => 'give_note', 'label' => 'Give / Donate Note', 'type' => 'textarea'],
    ],
];

// Repeater fields per section: key => [label, subfields]
$repeater_defs = [
    'local-church'  => ['key' => 'schedule', 'label' => 'Weekly Schedule', 'fields' => ['day' => 'Day', 'time' => 'Time', 'what' => 'What']],
    'sunday-school' => ['key' => 'classes', 'label' => 'Classes', 'fields' => ['name' => 'Class Name', 'ages' => 'Ages', 'focus' => 'Focus']],
    'welfare'       => ['key' => 'programs', 'label' => 'Programmes', 'fields' => ['name' => 'Programme Name', 'detail' => 'Detail']],
];

$active = $_GET['section'] ?? 'home';
if (!array_key_exists($active, $sections)) $active = 'home';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $section = $_POST['section'] ?? $active;
    if (array_key_exists($section, $sections)) $active = $section;

    if ($action === 'upload_photo') {
        [$ok, $msg] = handle_upload('photo', $section);
        $message = $ok ? 'Photo uploaded.' : $msg;
    } elseif ($action === 'delete_photo') {
        delete_image($section, $_POST['file'] ?? '');
        $message = 'Photo removed.';
    } elseif ($action === 'save_content') {
        $data = get_json($section);
        foreach ($_POST as $key => $val) {
            if (in_array($key, ['action', 'section'], true)) continue;
            if (is_array($val) && isset($repeater_defs[$section]) && $repeater_defs[$section]['key'] === $key) {
                // Drop blank spare rows
                $val = array_values(array_filter($val, function ($row) {
                    return count(array_filter($row, fn($v) => trim((string)$v) !== '')) > 0;
                }));
            }
            $data[$key] = $val;
        }
        save_json($section, $data);
        $message = 'Content saved.';
    }
}

$content = get_json($active);
$photos = get_images($active === 'home' ? 'hero' : $active);
$gallery_section = $active === 'home' ? 'hero' : $active;
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Admin — <?= h($sections[$active]) ?> — <?= h(SITE_NAME) ?></title>
<link rel="icon" href="data:,">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body class="admin-body">
<div class="admin-shell">
  <aside class="admin-sidebar">
    <span class="brand-name"><?= h(SITE_SHORT) ?><small>Church Admin</small></span>
    <nav class="admin-nav">
      <?php foreach ($sections as $slug => $label): ?>
        <a href="?section=<?= h($slug) ?>" class="<?= $active === $slug ? 'active' : '' ?>"><?= h($label) ?></a>
      <?php endforeach; ?>
    </nav>
    <a href="../index.php" class="view-site" target="_blank">View live site &rarr;</a>
    <a href="logout.php" class="logout-link">Sign out</a>
  </aside>

  <main class="admin-main">
    <h1><?= h($sections[$active]) ?></h1>
    <p class="sub">Update photos and text for this section of the website.</p>

    <?php if ($message): ?><div class="admin-flash"><?= h($message) ?></div><?php endif; ?>

    <!-- Photos -->
    <div class="admin-panel">
      <h2>Photos</h2>
      <?php if (!empty($photos)): ?>
        <div class="photo-grid">
          <?php foreach ($photos as $file): ?>
            <figure>
              <img src="../<?= h(image_url($gallery_section, $file)) ?>" alt="">
              <form method="post" onsubmit="return confirm('Remove this photo?');">
                <input type="hidden" name="action" value="delete_photo">
                <input type="hidden" name="section" value="<?= h($gallery_section) ?>">
                <input type="hidden" name="file" value="<?= h($file) ?>">
                <button type="submit" class="del">Remove</button>
              </form>
            </figure>
          <?php endforeach; ?>
        </div>
      <?php else: ?>
        <p class="sub" style="margin-bottom:16px">No photos uploaded yet for this section.</p>
      <?php endif; ?>
      <form method="post" enctype="multipart/form-data" class="upload-row">
        <input type="hidden" name="action" value="upload_photo">
        <input type="hidden" name="section" value="<?= h($gallery_section) ?>">
        <input type="file" name="photo" accept=".jpg,.jpeg,.png,.webp" required>
        <button type="submit" class="btn btn-outline-dark">Upload Photo</button>
      </form>
    </div>

    <!-- Text content -->
    <?php if (!empty($field_defs[$active]) || !empty($repeater_defs[$active])): ?>
    <div class="admin-panel">
      <h2>Page Text</h2>
      <form method="post">
        <input type="hidden" name="action" value="save_content">
        <input type="hidden" name="section" value="<?= h($active) ?>">

        <?php foreach ($field_defs[$active] as $f): ?>
          <div class="field">
            <label for="<?= h($f['key']) ?>"><?= h($f['label']) ?></label>
            <?php if ($f['type'] === 'textarea'): ?>
              <textarea id="<?= h($f['key']) ?>" name="<?= h($f['key']) ?>"><?= h($content[$f['key']] ?? '') ?></textarea>
            <?php else: ?>
              <input type="text" id="<?= h($f['key']) ?>" name="<?= h($f['key']) ?>" value="<?= h($content[$f['key']] ?? '') ?>">
            <?php endif; ?>
          </div>
        <?php endforeach; ?>

        <?php if (isset($repeater_defs[$active])):
            $rep = $repeater_defs[$active];
            $rows = $content[$rep['key']] ?? [];
            $spare = 2;
            $total = count($rows) + $spare;
        ?>
          <div class="field">
            <label><?= h($rep['label']) ?></label>
            <?php for ($i = 0; $i < $total; $i++): $row = $rows[$i] ?? []; ?>
              <div class="repeater-row">
                <?php foreach ($rep['fields'] as $fkey => $flabel): ?>
                  <div class="field">
                    <label><?= h($flabel) ?></label>
                    <input type="text" name="<?= h($rep['key']) ?>[<?= $i ?>][<?= h($fkey) ?>]" value="<?= h($row[$fkey] ?? '') ?>">
                  </div>
                <?php endforeach; ?>
              </div>
            <?php endfor; ?>
            <p class="sub" style="margin:0">Leave rows blank to remove them. Extra blank rows are ignored until filled in.</p>
          </div>
        <?php endif; ?>

        <button type="submit" class="btn btn-primary">Save Changes</button>
      </form>
    </div>
    <?php endif; ?>
  </main>
</div>
</body>
</html>
