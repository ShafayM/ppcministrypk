<?php
require_once __DIR__ . '/../includes/config.php';

if (is_admin()) {
    header('Location: index.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'] ?? '';
    if (password_verify($password, ADMIN_PASSWORD_HASH)) {
        $_SESSION['ppc_admin'] = true;
        header('Location: index.php');
        exit;
    }
    $error = 'Incorrect password. Please try again.';
}
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Church Admin — <?= h(SITE_NAME) ?></title>
<link rel="icon" href="data:,">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body class="admin-body">
<div class="admin-login-wrap">
  <div class="admin-login-card">
    <span class="eyebrow">Church Admin</span>
    <h1>Sign in</h1>
    <p class="sub">Manage photos and page content for <?= h(SITE_NAME) ?>.</p>
    <?php if ($error): ?><div class="admin-flash" style="background:rgba(226,84,45,.12);border-color:var(--ember)"><?= h($error) ?></div><?php endif; ?>
    <form method="post">
      <div class="field">
        <label for="password">Admin password</label>
        <input type="password" id="password" name="password" required autofocus>
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center">Sign In</button>
    </form>
    <p class="sub" style="margin-top:20px;margin-bottom:0"><a href="../index.php" style="color:var(--ember);font-weight:600">&larr; Back to site</a></p>
  </div>
</div>
</body>
</html>
